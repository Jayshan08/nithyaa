-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 27, 2021 at 12:15 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecommerce`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `getcat` (IN `cid` INT)  SELECT * FROM categories WHERE cat_id=cid$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admin_info`
--

CREATE TABLE `admin_info` (
  `admin_id` int(10) NOT NULL,
  `admin_name` varchar(100) NOT NULL,
  `admin_email` varchar(300) NOT NULL,
  `admin_password` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_info`
--

INSERT INTO `admin_info` (`admin_id`, `admin_name`, `admin_email`, `admin_password`) VALUES
(1, 'admin', 'admin@gmail.com', '123456789');

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `brand_id` int(100) NOT NULL,
  `brand_title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`brand_id`, `brand_title`) VALUES
(6, 'Cloth Brand');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(10) NOT NULL,
  `p_id` int(10) NOT NULL,
  `ip_add` varchar(250) NOT NULL,
  `user_id` int(10) DEFAULT NULL,
  `qty` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `p_id`, `ip_add`, `user_id`, `qty`) VALUES
(6, 26, '::1', 4, 1),
(9, 10, '::1', 7, 1),
(10, 11, '::1', 7, 1),
(11, 45, '::1', 7, 1),
(44, 5, '::1', 3, 0),
(46, 2, '::1', 3, 0),
(49, 60, '::1', 8, 1),
(50, 61, '::1', 8, 1),
(51, 1, '::1', 8, 1),
(52, 5, '::1', 9, 1),
(53, 2, '::1', 14, 1),
(54, 3, '::1', 14, 1),
(55, 5, '::1', 14, 1),
(56, 1, '::1', 9, 1),
(57, 2, '::1', 9, 1),
(71, 61, '127.0.0.1', -1, 1),
(149, 3, '::1', 26, 1);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(100) NOT NULL,
  `cat_title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`) VALUES
(1, 'Crafts'),
(2, 'Ladies Wears'),
(3, 'Mens Wear'),
(4, 'Jewellery'),
(5, 'Furnitures'),
(6, 'Wall decor'),
(7, 'stationairy');

-- --------------------------------------------------------

--
-- Table structure for table `email_info`
--

CREATE TABLE `email_info` (
  `email_id` int(100) NOT NULL,
  `email` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `email_info`
--

INSERT INTO `email_info` (`email_id`, `email`) VALUES
(3, 'admin@gmail.com'),
(4, 'jayshankarjaya@gmail.com'),
(5, 'hemarajhnh@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `action` varchar(50) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `trx_id` varchar(255) NOT NULL,
  `p_status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `user_id`, `product_id`, `qty`, `trx_id`, `p_status`) VALUES
(2, 14, 2, 1, '07M47684BS5725041', 'Completed');

-- --------------------------------------------------------

--
-- Table structure for table `orders_info`
--

CREATE TABLE `orders_info` (
  `order_id` int(10) NOT NULL,
  `user_id` int(11) NOT NULL,
  `f_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zip` int(10) NOT NULL,
  `cardname` varchar(255) NOT NULL,
  `cardnumber` varchar(20) NOT NULL,
  `expdate` varchar(255) NOT NULL,
  `prod_count` int(15) DEFAULT NULL,
  `total_amt` int(15) DEFAULT NULL,
  `cvv` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders_info`
--

INSERT INTO `orders_info` (`order_id`, `user_id`, `f_name`, `email`, `address`, `city`, `state`, `zip`, `cardname`, `cardnumber`, `expdate`, `prod_count`, `total_amt`, `cvv`) VALUES
(1, 12, 'jayshankar', 'jayshankarjaya@gmail.com', 'Hassan,Karnataka', 'hassan', 'Karnataka', 573201, '87452364153', '4321 2345 6788 7654', '12/90', 3, 77000, 1234),
(2, 26, 'jeevan kumar', 'jeevan@gmail.com', 'hassan', 'hassan', 'karntaka', 573201, 'jeevan', '78954103665', '12/22', 1, 5000, 123),
(3, 27, 'tarunpatel t', 'tarunpatel@gmail.com', 'hassan', 'hassan', 'karntaka', 573201, 'tarun', '5462 1398 7811', '12/22', 1, 800, 123);

-- --------------------------------------------------------

--
-- Table structure for table `order_products`
--

CREATE TABLE `order_products` (
  `order_pro_id` int(10) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `qty` int(15) DEFAULT NULL,
  `amt` int(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_products`
--

INSERT INTO `order_products` (`order_pro_id`, `order_id`, `product_id`, `qty`, `amt`) VALUES
(73, 1, 1, 1, 5000),
(74, 1, 4, 2, 64000),
(75, 1, 8, 1, 40000),
(91, 2, 1, 1, 5000),
(92, 3, 3, 1, 800);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(100) NOT NULL,
  `product_cat` int(100) NOT NULL,
  `product_brand` int(100) NOT NULL,
  `product_title` varchar(255) NOT NULL,
  `product_price` int(100) NOT NULL,
  `product_desc` text NOT NULL,
  `product_image` text NOT NULL,
  `product_keywords` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_cat`, `product_brand`, `product_title`, `product_price`, `product_desc`, `product_image`, `product_keywords`) VALUES
(1, 1, 2, 'Wooden Kokeshi Bowling Set', 700, 'Wooden Kokeshi Bowling Set', 'c1.jpg', 'Wooden Kokeshi Bowling Set'),
(2, 1, 3, 'Wooden Kokeshi Dolls', 650, 'Wooden Kokeshi Dolls', 'c2.jpg', 'Wooden Kokeshi Dolls'),
(3, 1, 3, 'Gajananda Wooden Key Hanger', 800, 'Gajananda Wooden Key Hanger', 'c3.jpg', 'Gajananda Wooden Key Hanger'),
(4, 1, 3, 'Rakshak Wooden Bajrangbali', 400, 'Rakshak Wooden Bajrangbali', 'c4.jpg', 'Rakshak Wooden Bajrangbali'),
(5, 1, 2, 'Mayur Wooden Nauka', 1000, 'Mayur Wooden Nauka', 'c5.jpg', 'Mayur Wooden Nauka'),
(6, 1, 1, 'Rangeela Wooden Rickshaw', 350, 'Rangeela Wooden Rickshaw', 'c6.jpg', 'Rangeela Wooden Rickshaw'),
(7, 1, 1, 'Jhumroo Wooden Rickshaw', 500, 'Jhumroo Wooden Rickshaw', 'c7.jpg', 'Jhumroo Wooden Rickshaw'),
(8, 1, 4, 'Ekdanta Wooden Showpiece', 700, 'Ekdanta Wooden Showpiece', 'c8.jpg', 'Ekdanta Wooden Showpiece'),
(9, 1, 3, 'Morpankh Wooden Darbaar', 800, 'Morpankh Wooden Darbaar', 'c9.jpg', 'Morpankh Wooden Darbaar'),
(10, 2, 6, 'Sareen Aksi Stole', 1000, 'Sareen Aksi Stole', 'w1.jpg', 'Sareen Aksi Stole'),
(11, 2, 6, 'Bareen Aksi Stole', 1200, 'Bareen Aksi Stole', 'w2.jpg', 'Bareen Aksi Stole'),
(12, 2, 6, 'Jendayi Shawl', 1500, 'Jendayi Shawl', 'w3.jpg', 'Jendayi Shawl'),
(13, 2, 6, 'Paru Handwoven Shawl', 1500, 'Paru Handwoven Shawl', 'w4.jpg', 'Paru Handwoven Shawl'),
(14, 2, 6, 'Khevna Handwoven Shawl', 1700, 'Khevna Handwoven Shawl', 'w5.jpg', 'Khevna Handwoven Shawl'),
(15, 2, 6, 'Halvad Handwoven Shawl', 1600, 'Halvad Handwoven Shawl', 'w6.jpg', 'Halvad Handwoven Shawl'),
(22, 4, 6, 'Dhankya Pottery Necklace', 1300, 'Dhankya Pottery Necklace', 'j1.jpg', 'Dhankya Pottery Necklace'),
(23, 4, 6, 'Amet Brass Necklace', 1900, 'Amet Brass Necklace', 'j2.jpg', 'Amet Brass Necklace'),
(24, 4, 6, 'Amet Brass Earrings', 700, 'Amet Brass Earrings', 'j3.jpg', 'Amet Brass Earrings'),
(25, 4, 6, 'Gul Kundan Earrings', 750, 'Gul Kundan Earrings', 'j4.jpg', 'Gul Kundan Earrings'),
(27, 4, 6, 'Valaya Pearl Drop Earrings', 690, 'Valaya Pearl Drop Earrings', 'j5.jpg', 'Valaya Pearl Drop Earrings'),
(32, 5, 0, 'Book Shelf', 2500, 'book shelf', 'furniture-book-shelf-250x250.jpg', 'book shelf furniture'),
(33, 6, 2, 'Jewel Relif work', 3500, 'Jewel Relif work', 'wall2.jpg', 'jewel walldecor'),
(34, 6, 4, 'cherry poise', 1000, 'cherry poise', 'wall3.jpg', 'cherry poise'),
(35, 6, 0, 'Sage work', 6000, 'Sage work', 'wall4.jpg', 'Sage work'),
(36, 6, 5, 'Bater Madhubani', 1500, '', 'wall5.jpg', 'Bater Madhubani'),
(37, 6, 5, 'Zied Relief work', 2000, 'Zied Relief work', 'wall6.jpg', 'Zied Relief wall decor'),
(38, 6, 4, 'Gull wall art', 3500, 'Gull wall', 'wall7.jpg', 'Gull wall art'),
(39, 6, 5, 'Tangerine', 2500, 'tangerian', 'wall1.jpg', 'Tangerian'),
(40, 2, 6, 'Sera Handwoven Stole', 1800, 'Sera Handwoven Stole', 'w7.jpg', 'ladies'),
(47, 4, 6, 'Baseri Pottery Necklace', 650, 'Baseri Pottery Necklace', 'j6.jpg', 'Baseri Pottery Necklace'),
(54, 3, 6, 'Nut Men\'s Muffler', 400, 'Nut Men\'s Muffler', 'm1.jpg', 'Nut Men\'s Muffler'),
(55, 3, 6, 'Hehet Men\'s Muffler', 450, 'Hehet Men\'s Muffler', 'm2.jpg', 'Hehet Men\'s Muffler'),
(56, 3, 6, 'Paz Men\'s Shawl', 600, 'Paz Men\'s Shawl', 'm3.jpg', 'Paz Men\'s Shawl'),
(57, 3, 6, 'Lainil Men\'s Shawl', 700, 'Lainil Men\'s Shawl', 'm4.jpg', 'Lainil Men\'s Shawl'),
(58, 3, 6, 'Rustic Handspun Shawl', 500, 'Rustic Handspun Shawl', 'm5.jpg', 'Rustic Handspun Shawl'),
(59, 3, 6, 'Romir Handwoven Muffler', 600, 'Romir Handwoven Muffler', 'm6.jpg', 'Romir Handwoven Muffler'),
(60, 3, 6, 'Rasik Handwoven Muffler', 700, 'Rasik Handwoven Muffler', 'm7.jpg', 'Rasik Handwoven Muffler'),
(61, 3, 6, 'Harela Men\'s Muffler', 800, 'Harela Men\'s Muffler', 'm8.jpg', 'Harela Men\'s Muffler'),
(72, 7, 2, 'Vedai Blue Pen Stand', 3500, 'Vedai Blue Pen Stand', 's1.jpg', 'Vedai Blue Pen Stand'),
(73, 7, 2, 'Awoora Leaf Motif Pen Stand', 3500, 'Awoora Leaf Motif Pen Stand', 's2.jpg', 'Awoora Leaf Motif Pen Stand'),
(79, 7, 2, 'Moroccan Pen Stand', 2569, 'Moroccan Pen Stand', 's3.jpg', 'Moroccan Pen Stand'),
(82, 2, 2, 'Ravista Chanderi Saree', 1000, 'Ravista Chanderi Saree', '1622967858_w10.jpg', 'Ravista Chanderi Saree');

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `user_id` int(10) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `address1` varchar(300) NOT NULL,
  `address2` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`user_id`, `first_name`, `last_name`, `email`, `password`, `mobile`, `address1`, `address2`) VALUES
(12, 'jayshankar', 'jay', 'jayshankarjaya@gmail.com', '123456789', '8970109660', 'Hassan', 'Hassan'),
(16, 'hemaraj', 'hn', 'hemarajhnh@gmail.com', '123456789', '9978451263', 'hn pura', 'hassan'),
(26, 'jeevan', 'kumar', 'jeevan@gmail.com', '123456789', '8970109360', 'hassan', 'hassan'),
(27, 'tarunpatel', 't', 'tarunpatel@gmail.com', 'tarunpatel', '7841256931', 'hassan', 'hassan');

--
-- Triggers `user_info`
--
DELIMITER $$
CREATE TRIGGER `after_user_info_insert` AFTER INSERT ON `user_info` FOR EACH ROW BEGIN 
INSERT INTO user_info_backup VALUES(new.user_id,new.first_name,new.last_name,new.email,new.password,new.mobile,new.address1,new.address2);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `user_info_backup`
--

CREATE TABLE `user_info_backup` (
  `user_id` int(10) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `address1` varchar(300) NOT NULL,
  `address2` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_info_backup`
--

INSERT INTO `user_info_backup` (`user_id`, `first_name`, `last_name`, `email`, `password`, `mobile`, `address1`, `address2`) VALUES
(12, 'jayshankar', 'jay', 'jayshankarjaya@gmail.com', '123456789', '8970109660', '123456789', 'Hassan'),
(15, 'hemaraj', 'HN', 'hemarajhnh@gmail.com', '12345678', '9452163647', 'HN pura', 'Hassan'),
(19, 'brunda', ' K R', 'brundakr@gmail.com', '123456789', '9871236534', 'bangalore', 'hassan'),
(26, 'jeevan', 'kumar', 'jeevan@gmail.com', '123456789', '8970109360', 'hassan', 'hassan'),
(27, 'tarunpatel', 't', 'tarunpatel@gmail.com', 'tarunpatel', '7841256931', 'hassan', 'hassan');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_info`
--
ALTER TABLE `admin_info`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `email_info`
--
ALTER TABLE `email_info`
  ADD PRIMARY KEY (`email_id`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `orders_info`
--
ALTER TABLE `orders_info`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `order_products`
--
ALTER TABLE `order_products`
  ADD PRIMARY KEY (`order_pro_id`),
  ADD KEY `order_products` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_info_backup`
--
ALTER TABLE `user_info_backup`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_info`
--
ALTER TABLE `admin_info`
  MODIFY `admin_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `brand_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=156;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `email_info`
--
ALTER TABLE `email_info`
  MODIFY `email_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `orders_info`
--
ALTER TABLE `orders_info`
  MODIFY `order_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `order_products`
--
ALTER TABLE `order_products`
  MODIFY `order_pro_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=93;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;

--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `user_info_backup`
--
ALTER TABLE `user_info_backup`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders_info`
--
ALTER TABLE `orders_info`
  ADD CONSTRAINT `user_id` FOREIGN KEY (`user_id`) REFERENCES `user_info` (`user_id`);

--
-- Constraints for table `order_products`
--
ALTER TABLE `order_products`
  ADD CONSTRAINT `order_products` FOREIGN KEY (`order_id`) REFERENCES `orders_info` (`order_id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `product_id` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
